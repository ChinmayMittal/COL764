#ifndef DOCUMENT_H
#define DOCUMENT_H

#include<string>

struct Document {
    std::string docID;
    std::string title;
    std::string content;
};

#endif // DOCUMENT_H